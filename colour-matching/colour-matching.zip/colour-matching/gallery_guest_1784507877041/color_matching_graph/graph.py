"""Typed adaptive execution graph.

Topology (sequential because each design depends on prior measurements):
start -> initialize -> design -> make -> test -> analyze -> decision
                         ^                              | continue
                         |______________________________|
                                                stop -> finalize -> end
"""
from __future__ import annotations

import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import logfire
from pydantic_graph.graph_builder import Graph, GraphBuilder
from pydantic_graph.step import StepContext
from pydantic_graph.util import TypeExpression

from .designer import Designer, LLMDesigner, PROMPT_VERSION
from .mcp_client import MCPColorRobot
from .models import (
    AnalysisDecision, ColorMatchingResult, ExperimentObservation, InitToken,
    MadeExperiment, SourceInput, WorkflowState,
)
from .provenance import finalize_files, record_progress

logfire.configure(send_to_logfire=False)
logfire.instrument_pydantic_ai()
logfire.instrument_httpx(capture_all=True)

GRAPH_NAME = "adaptive_color_matching"
GRAPH_VERSION = "0.1.0"


class Robot(Protocol):
    async def connect(self) -> None: ...
    async def close(self) -> None: ...
    async def initialize(self) -> None: ...
    async def return_home(self) -> None: ...
    async def make_recipe(self, well, recipe, source_wells) -> None: ...
    async def color_diff(self, well, target_hex) -> float: ...


@dataclass
class WorkflowDeps:
    run_root: Path
    designer: Designer
    robot: Robot
    dry_run: bool = False


def _relative(state: WorkflowState, filename: str) -> str:
    return filename


def build_color_matching_graph() -> Graph[WorkflowState, WorkflowDeps, None, ColorMatchingResult]:
    g = GraphBuilder(
        name=GRAPH_NAME,
        state_type=WorkflowState,
        deps_type=WorkflowDeps,
        output_type=ColorMatchingResult,
    )

    @g.step(node_id="initialize_robot")
    async def initialize_robot(ctx: StepContext[WorkflowState, WorkflowDeps, None]) -> InitToken:
        try:
            await ctx.deps.robot.connect()
            await ctx.deps.robot.initialize()
            record_progress(ctx.state, "robot_initialized", mcp_url=getattr(ctx.deps.robot, "url", "injected"))
            logfire.info("Color robot initialized", run_id=ctx.state.run_id)
            return InitToken()
        except Exception:
            ctx.state.status = "failed"
            ctx.state.stop_reason = "failed"
            ctx.state.failure_messages.append(traceback.format_exc())
            record_progress(ctx.state, "initialize_failed", error=ctx.state.failure_messages[-1])
            return InitToken(ready=False)

    @g.step(node_id="design_experiment")
    async def design_experiment(
        ctx: StepContext[WorkflowState, WorkflowDeps, InitToken | AnalysisDecision],
    ) -> MadeExperiment:
        if ctx.state.status == "failed":
            raise RuntimeError("design reached after initialization failure")
        well = ctx.state.next_well
        decision = await ctx.deps.designer.design(
            ctx.state.source_input.target_hex,
            list(ctx.state.observations),
            well,
        )
        ctx.state.current_design = decision
        ctx.state.routing_history.append({
            "well": well,
            "node": "design_experiment",
            "model": getattr(ctx.deps.designer, "model", "injected"),
            "prompt_version": PROMPT_VERSION,
            "recipe": decision.recipe.model_dump(mode="json"),
            "reasoning": decision.reasoning,
            "confidence": decision.confidence,
        })
        allocations = {
            color: ctx.state.allocate(color, volume)
            for color, volume in decision.recipe.as_color_dict().items()
            if volume > 0
        }
        record_progress(
            ctx.state, "experiment_designed", well=well,
            recipe=decision.recipe.model_dump(mode="json"),
            reasoning=decision.reasoning, confidence=decision.confidence,
            source_allocations=allocations,
        )
        return MadeExperiment(well=well, decision=decision, source_allocations=allocations)

    @g.step(node_id="make_experiment")
    async def make_experiment(
        ctx: StepContext[WorkflowState, WorkflowDeps, MadeExperiment],
    ) -> MadeExperiment:
        item = ctx.inputs
        await ctx.deps.robot.make_recipe(item.well, item.decision.recipe, item.source_allocations)
        record_progress(ctx.state, "experiment_made", well=item.well, recipe=item.decision.recipe.model_dump(mode="json"))
        return item

    @g.step(node_id="test_experiment")
    async def test_experiment(
        ctx: StepContext[WorkflowState, WorkflowDeps, MadeExperiment],
    ) -> ExperimentObservation:
        item = ctx.inputs
        # The camera must see the destination unobstructed. Move the arm home
        # before get_color_diff triggers image capture and colour analysis.
        await ctx.deps.robot.return_home()
        record_progress(ctx.state, "camera_cleared", well=item.well, robot_position="home")
        difference = await ctx.deps.robot.color_diff(item.well, ctx.state.source_input.target_hex)
        observation = ExperimentObservation(
            well=item.well,
            recipe=item.decision.recipe,
            difference=difference,
            design_reasoning=item.decision.reasoning,
            confidence=item.decision.confidence,
        )
        record_progress(ctx.state, "experiment_tested", **observation.model_dump(mode="json"))
        return observation

    @g.step(node_id="analyze_result")
    async def analyze_result(
        ctx: StepContext[WorkflowState, WorkflowDeps, ExperimentObservation],
    ) -> AnalysisDecision:
        observation = ctx.inputs
        ctx.state.observations.append(observation)
        ctx.state.next_well += 1
        best = min(ctx.state.observations, key=lambda item: item.difference)
        if observation.difference < ctx.state.source_input.threshold:
            ctx.state.stop_reason = "threshold_reached"
            decision = AnalysisDecision(continue_experimenting=False, stop_reason="threshold_reached", latest=observation)
        elif len(ctx.state.observations) >= ctx.state.source_input.max_wells or ctx.state.next_well >= 12:
            ctx.state.status = "partial"
            ctx.state.stop_reason = "wells_exhausted"
            decision = AnalysisDecision(continue_experimenting=False, stop_reason="wells_exhausted", latest=observation)
        else:
            decision = AnalysisDecision(continue_experimenting=True, latest=observation)
        record_progress(
            ctx.state, "result_analyzed", well=observation.well,
            difference=observation.difference, best_well=best.well,
            best_difference=best.difference, continue_experimenting=decision.continue_experimenting,
            stop_reason=decision.stop_reason,
        )
        return decision

    @g.step(node_id="finalize")
    async def finalize(
        ctx: StepContext[WorkflowState, WorkflowDeps, InitToken | AnalysisDecision],
    ) -> ColorMatchingResult:
        state = ctx.state
        if state.stop_reason is None:
            state.stop_reason = "failed"
        best = min(state.observations, key=lambda item: item.difference) if state.observations else None
        if state.stop_reason == "threshold_reached":
            state.status = "ok"
        elif state.stop_reason == "wells_exhausted" and state.status == "ok":
            state.status = "partial"
        try:
            await ctx.deps.robot.return_home()
        except Exception:
            state.failure_messages.append("return_home failed:\n" + traceback.format_exc())
            if state.status == "ok":
                state.status = "partial"
        try:
            await ctx.deps.robot.close()
        except Exception:
            state.failure_messages.append("MCP close failed:\n" + traceback.format_exc())
            if state.status == "ok":
                state.status = "partial"
        result = ColorMatchingResult(
            run_id=state.run_id,
            status=state.status,
            is_real_result=not ctx.deps.dry_run,
            target_hex=state.source_input.target_hex,
            threshold=state.source_input.threshold,
            stop_reason=state.stop_reason,
            filled_wells=len(state.observations),
            best_difference=None if best is None else best.difference,
            best_well=None if best is None else best.well,
            best_recipe=None if best is None else best.recipe,
            observations=list(state.observations),
            progress_log_path=_relative(state, "progress.jsonl"),
            final_json_path=_relative(state, "final.json"),
            provenance_path=_relative(state, "provenance.json"),
            failure_messages=list(state.failure_messages),
        )
        record_progress(state, "workflow_finalized", status=result.status, stop_reason=result.stop_reason, filled_wells=result.filled_wells, best_difference=result.best_difference)
        finalize_files(state, result, GRAPH_NAME, GRAPH_VERSION)
        return result

    route = (
        g.decision(node_id="continue_or_stop")
        .branch(g.match(TypeExpression[AnalysisDecision], matches=lambda x: x.continue_experimenting).to(design_experiment))
        .branch(g.match(TypeExpression[AnalysisDecision], matches=lambda x: not x.continue_experimenting).to(finalize))
    )

    init_route = (
        g.decision(node_id="initialization_route")
        .branch(g.match(TypeExpression[InitToken], matches=lambda x: x.ready).to(design_experiment))
        .branch(g.match(TypeExpression[InitToken], matches=lambda x: not x.ready).to(finalize))
    )

    g.add(
        g.edge_from(g.start_node).to(initialize_robot),
        g.edge_from(initialize_robot).to(init_route),
        g.edge_from(design_experiment).to(make_experiment),
        g.edge_from(make_experiment).to(test_experiment),
        g.edge_from(test_experiment).to(analyze_result),
        g.edge_from(analyze_result).to(route),
        g.edge_from(finalize).to(g.end_node),
    )
    return g.build()
