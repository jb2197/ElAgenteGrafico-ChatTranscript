from __future__ import annotations

import hashlib
import json
import logging
import platform
import sys
from datetime import UTC, datetime
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any

from .models import ColorMatchingResult, WorkflowState


def now_iso() -> str:
    return datetime.now(UTC).isoformat()


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=True), encoding="utf-8")


def setup_run(state: WorkflowState, run_root: Path, dry_run: bool) -> Path:
    run_dir = run_root / state.run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    state.run_dir = str(run_dir)
    write_json(run_dir / "source_input.json", state.source_input.model_dump(mode="json"))
    packages = {}
    for name in ("pydantic", "pydantic-ai", "pydantic-graph", "mcp", "logfire"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            packages[name] = None
    write_json(
        run_dir / "environment.json",
        {"python": sys.version, "platform": platform.platform(), "dry_run": dry_run, "packages": packages},
    )
    return run_dir


def logger_for(state: WorkflowState) -> logging.Logger:
    logger = logging.getLogger(f"color_matching.{state.run_id}")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if not logger.handlers:
        handler = logging.FileHandler(Path(state.run_dir) / "run.log", encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(handler)
    return logger


def record_progress(state: WorkflowState, event: str, **data: Any) -> None:
    payload = {"timestamp": now_iso(), "event": event, **data}
    state.step_records.append(payload)
    path = Path(state.run_dir) / "progress.jsonl"
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=True) + "\n")
    logger_for(state).info("%s %s", event, json.dumps(data, ensure_ascii=True))


def sha256(path: Path) -> str:
    digest = hashlib.sha256(path.read_bytes())
    return digest.hexdigest()


def finalize_files(state: WorkflowState, result: ColorMatchingResult, graph_name: str, graph_version: str) -> None:
    run_dir = Path(state.run_dir)
    final_path = run_dir / "final.json"
    write_json(final_path, result.model_dump(mode="json"))
    artifacts = []
    for path in sorted(run_dir.iterdir()):
        if path.is_file() and path.name != "provenance.json":
            artifacts.append({"path": path.name, "size_bytes": path.stat().st_size, "sha256": sha256(path)})
    write_json(
        run_dir / "provenance.json",
        {
            "run_id": state.run_id,
            "graph_name": graph_name,
            "graph_version": graph_version,
            "started_at": state.started_at,
            "ended_at": now_iso(),
            "status": result.status,
            "source_input": state.source_input.model_dump(mode="json"),
            "routing_history": state.routing_history,
            "steps": state.step_records,
            "failure_messages": state.failure_messages,
            "artifacts": artifacts,
        },
    )
