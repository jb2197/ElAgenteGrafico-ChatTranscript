from __future__ import annotations

import json
import os
from typing import Protocol

from pydantic_ai import Agent
from pydantic_ai.capabilities import Thinking

from .models import DesignDecision, ExperimentObservation

DEFAULT_MODEL = "openai-responses:gpt-5.6-luna"
PROMPT_VERSION = "color-design-v2-general"
SYSTEM_PROMPT = (
    "You design adaptive three-primary liquid color-mixing experiments. "
    "The available source liquids are red, yellow, and blue. The requested target is supplied "
    "at runtime as a hexadecimal RGB colour; reason from that value rather than assuming any "
    "particular hue. Return one typed DesignDecision. Volumes are integer microliters, each "
    "between 0 and 1000, and MUST sum exactly to 1000. Minimize measured CIEDE2000 difference. "
    "Use all previous recipes and measurements quantitatively, balance exploration with local "
    "refinement, avoid exact duplicates, and choose the single most informative next experiment. "
    "Do not assume ideal additive RGB mixing: learn the real red/yellow/blue liquid response from "
    "the observations. Explain the choice briefly."
)


class Designer(Protocol):
    async def design(self, target_hex: str, observations: list[ExperimentObservation], next_well: int) -> DesignDecision: ...


class LLMDesigner:
    """Typed LLM operation that proposes the next physically executed recipe."""

    def __init__(self, model: str | None = None):
        self.model = model or os.environ.get("COLOR_MATCHING_MODEL", DEFAULT_MODEL)

    def _agent(self) -> Agent[None, DesignDecision]:
        return Agent(
            self.model,
            output_type=DesignDecision,
            system_prompt=SYSTEM_PROMPT,
            capabilities=[Thinking(effort="medium")],
            retries=2,
        )

    async def design(self, target_hex: str, observations: list[ExperimentObservation], next_well: int) -> DesignDecision:
        history = [item.model_dump(mode="json") for item in observations]
        prompt = (
            f"Prompt version: {PROMPT_VERSION}\nTarget: {target_hex}\nNext well: {next_well}\n"
            f"Measured experiment history: {json.dumps(history, ensure_ascii=True)}\n"
            "Propose the best next 1000 uL recipe."
        )
        decision = (await self._agent().run(prompt)).output
        prior = {tuple(obs.recipe.as_color_dict().values()) for obs in observations}
        candidate = tuple(decision.recipe.as_color_dict().values())
        if candidate in prior:
            retry_prompt = prompt + "\nYour proposed recipe duplicates a prior experiment. Return a distinct recipe."
            decision = (await self._agent().run(retry_prompt)).output
        return decision
