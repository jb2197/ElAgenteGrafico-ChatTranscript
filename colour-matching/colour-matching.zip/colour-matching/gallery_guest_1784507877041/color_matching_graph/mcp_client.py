from __future__ import annotations

import json
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator

from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client

from .models import ColorRecipe


class MCPColorRobot:
    """Task-safe adapter around the color-matching MCP server.

    GraphBuilder may run adjacent nodes in different async tasks. MCP streamable
    HTTP sessions own AnyIO cancel scopes, so each high-level robot operation
    opens and closes its session in the same task.
    """

    required_tools = {
        "initialize", "return_home", "move_color_well", "move_mix_well",
        "aspirate", "dispense", "mix_well", "wash_tip", "get_color_diff",
    }

    def __init__(self, url: str = "http://localhost:8001/mcp", *, reset_before_run: bool = False):
        self.url = url
        self.reset_before_run = reset_before_run

    @asynccontextmanager
    async def _session(self) -> AsyncIterator[ClientSession]:
        async with streamable_http_client(self.url) as (read_stream, write_stream, _):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()
                yield session

    async def connect(self) -> None:
        async with self._session() as session:
            listed = await session.list_tools()
            names = {tool.name for tool in listed.tools}
            missing = self.required_tools - names
            if missing:
                raise RuntimeError(f"MCP server is missing required tools: {sorted(missing)}")

    async def close(self) -> None:
        return None

    @staticmethod
    async def _call(session: ClientSession, name: str, arguments: dict[str, Any] | None = None) -> Any:
        result = await session.call_tool(name, arguments or {})
        if getattr(result, "isError", False):
            raise RuntimeError(f"MCP tool {name} failed: {result}")
        structured = getattr(result, "structuredContent", None)
        if structured is not None:
            return structured
        for item in getattr(result, "content", []):
            text = getattr(item, "text", None)
            if text:
                try:
                    return json.loads(text)
                except json.JSONDecodeError:
                    return text
        return None

    async def initialize(self) -> None:
        async with self._session() as session:
            if self.reset_before_run:
                await self._call(session, "reset_simulation")
            await self._call(session, "initialize")

    async def return_home(self) -> None:
        async with self._session() as session:
            await self._call(session, "return_home")

    async def make_recipe(
        self,
        well: int,
        recipe: ColorRecipe,
        source_wells: dict[str, list[tuple[int, int]]],
    ) -> None:
        async with self._session() as session:
            for color in ("red", "yellow", "blue"):
                for source_well, volume_ul in source_wells.get(color, []):
                    if volume_ul <= 0:
                        continue
                    await self._call(session, "move_color_well", {"well": source_well})
                    await self._call(session, "aspirate", {"volume_ul": volume_ul})
                    await self._call(session, "move_mix_well", {"well": well})
                    await self._call(session, "dispense", {"volume_ul": volume_ul})
                    await self._call(session, "wash_tip", {"volume_ul": 1000, "cycles": 1})
            await self._call(session, "move_mix_well", {"well": well})
            await self._call(session, "mix_well", {"volume_ul": min(recipe.total_ul, 1000), "cycles": 3})

    async def color_diff(self, well: int, target_hex: str) -> float:
        async with self._session() as session:
            payload = await self._call(session, "get_color_diff", {"well": well, "hex": target_hex})
        if isinstance(payload, (int, float)):
            return float(payload)
        if isinstance(payload, dict):
            for key in ("result", "difference", "diff", "delta_e", "ciede2000"):
                if key in payload:
                    return float(payload[key])
            for value in payload.values():
                if isinstance(value, dict):
                    for key in ("result", "difference", "diff", "delta_e", "ciede2000"):
                        if key in value:
                            return float(value[key])
        raise RuntimeError(f"Could not parse color difference from MCP response: {payload!r}")
