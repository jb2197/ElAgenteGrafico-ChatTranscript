"""Recovery graph for a measurement completed before an adapter parse failure."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from pydantic import BaseModel, Field
from pydantic_graph.graph_builder import GraphBuilder
from pydantic_graph.step import StepContext

from .graph import GRAPH_NAME, GRAPH_VERSION, Robot, WorkflowDeps
from .models import ColorMatchingResult, ColorRecipe, ExperimentObservation, SourceInput, WorkflowState
from .provenance import finalize_files, record_progress, setup_run


class RecoveryInput(BaseModel):
    parent_run_id: str
    well: int = Field(ge=0, le=11)
    recipe: ColorRecipe
    difference: float = Field(ge=0)
    design_reasoning: str
    confidence: float = Field(ge=0, le=1)


@dataclass
class RecoveryDeps:
    robot: Robot
    dry_run: bool = False


def build_recovery_graph():
    g = GraphBuilder(
        name="color_matching_measurement_recovery",
        state_type=WorkflowState,
        deps_type=RecoveryDeps,
        input_type=RecoveryInput,
        output_type=ColorMatchingResult,
    )

    @g.step(node_id="recover_measurement")
    async def recover_measurement(ctx: StepContext[WorkflowState, RecoveryDeps, RecoveryInput]) -> ExperimentObservation:
        item = ctx.inputs
        observation = ExperimentObservation(
            well=item.well,
            recipe=item.recipe,
            difference=item.difference,
            design_reasoning=item.design_reasoning,
            confidence=item.confidence,
        )
        record_progress(ctx.state, "measurement_recovered", parent_run_id=item.parent_run_id, **observation.model_dump(mode="json"))
        return observation

    @g.step(node_id="analyze_recovered_measurement")
    async def analyze(ctx: StepContext[WorkflowState, RecoveryDeps, ExperimentObservation]) -> ExperimentObservation:
        observation = ctx.inputs
        ctx.state.observations.append(observation)
        ctx.state.next_well = observation.well + 1
        if observation.difference < ctx.state.source_input.threshold:
            ctx.state.status = "ok"
            ctx.state.stop_reason = "threshold_reached"
        else:
            ctx.state.status = "partial"
            ctx.state.stop_reason = "wells_exhausted"
        record_progress(
            ctx.state,
            "recovered_result_analyzed",
            difference=observation.difference,
            threshold=ctx.state.source_input.threshold,
            stop_reason=ctx.state.stop_reason,
        )
        return observation

    @g.step(node_id="finalize_recovery")
    async def finalize(ctx: StepContext[WorkflowState, RecoveryDeps, ExperimentObservation]) -> ColorMatchingResult:
        state = ctx.state
        try:
            await ctx.deps.robot.return_home()
        finally:
            await ctx.deps.robot.close()
        observation = ctx.inputs
        result = ColorMatchingResult(
            run_id=state.run_id,
            status=state.status,
            is_real_result=not ctx.deps.dry_run,
            target_hex=state.source_input.target_hex,
            threshold=state.source_input.threshold,
            stop_reason=state.stop_reason or "failed",
            filled_wells=1,
            best_difference=observation.difference,
            best_well=observation.well,
            best_recipe=observation.recipe,
            observations=[observation],
            progress_log_path="progress.jsonl",
            final_json_path="final.json",
            provenance_path="provenance.json",
            failure_messages=[],
        )
        record_progress(state, "recovery_finalized", status=result.status, best_difference=result.best_difference)
        finalize_files(state, result, GRAPH_NAME + "_recovery", GRAPH_VERSION)
        return result

    g.add(
        g.edge_from(g.start_node).to(recover_measurement),
        g.edge_from(recover_measurement).to(analyze),
        g.edge_from(analyze).to(finalize),
        g.edge_from(finalize).to(g.end_node),
    )
    return g.build()


async def run_recovery(
    recovery_input: RecoveryInput,
    *,
    source_input: SourceInput,
    run_root: Path,
    robot: Robot,
) -> ColorMatchingResult:
    state = WorkflowState(source_input=source_input)
    setup_run(state, run_root, dry_run=False)
    graph = build_recovery_graph()
    return await graph.run(state=state, deps=RecoveryDeps(robot=robot), inputs=recovery_input)
