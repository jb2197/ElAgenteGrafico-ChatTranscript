from __future__ import annotations

import asyncio
import traceback
from pathlib import Path

from .designer import Designer, LLMDesigner
from .graph import WorkflowDeps, build_color_matching_graph
from .mcp_client import MCPColorRobot
from .models import ColorMatchingResult, SourceInput, WorkflowState
from .provenance import finalize_files, record_progress, setup_run


async def run_color_matching(
    source_input: SourceInput,
    *,
    run_root: Path,
    designer: Designer | None = None,
    robot=None,
    mcp_url: str = "http://localhost:8001/mcp",
    dry_run: bool = False,
) -> ColorMatchingResult:
    state = WorkflowState(source_input=source_input)
    setup_run(state, run_root, dry_run)
    deps = WorkflowDeps(
        run_root=run_root,
        designer=designer or LLMDesigner(),
        robot=robot or MCPColorRobot(mcp_url),
        dry_run=dry_run,
    )
    graph = build_color_matching_graph()
    try:
        return await graph.run(state=state, deps=deps)
    except Exception:
        state.status = "failed"
        state.stop_reason = "failed"
        state.failure_messages.append(traceback.format_exc())
        record_progress(state, "workflow_failed", error=state.failure_messages[-1])
        try:
            await deps.robot.return_home()
        except Exception:
            pass
        try:
            await deps.robot.close()
        except Exception:
            pass
        best = min(state.observations, key=lambda item: item.difference) if state.observations else None
        result = ColorMatchingResult(
            run_id=state.run_id,
            status="failed",
            is_real_result=not dry_run,
            target_hex=source_input.target_hex,
            threshold=source_input.threshold,
            stop_reason="failed",
            filled_wells=len(state.observations),
            best_difference=None if best is None else best.difference,
            best_well=None if best is None else best.well,
            best_recipe=None if best is None else best.recipe,
            observations=list(state.observations),
            progress_log_path="progress.jsonl",
            final_json_path="final.json",
            provenance_path="provenance.json",
            failure_messages=list(state.failure_messages),
        )
        finalize_files(state, result, "adaptive_color_matching", "0.1.0")
        return result


def run_color_matching_sync(source_input: SourceInput, *, run_root: Path, **kwargs) -> ColorMatchingResult:
    return asyncio.run(run_color_matching(source_input, run_root=run_root, **kwargs))
