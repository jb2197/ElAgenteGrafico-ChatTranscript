from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, computed_field, field_validator, model_validator

ExecutionStatus = Literal["ok", "partial", "failed", "skipped"]
StopReason = Literal["threshold_reached", "wells_exhausted", "failed"]


class SourceInput(BaseModel):
    target_hex: str = "#eb4034"
    max_wells: int = Field(default=12, ge=1, le=12)
    threshold: float = Field(default=10.0, gt=0)
    recipe_total_ul: int = Field(default=1000, ge=100, le=1000)
    occupied_wells: list[int] = Field(default_factory=list)
    source_used_ul: dict[str, int] = Field(
        default_factory=lambda: {"red": 0, "yellow": 0, "blue": 0}
    )

    @field_validator("target_hex")
    @classmethod
    def valid_hex(cls, value: str) -> str:
        value = value.lower()
        if not re.fullmatch(r"#[0-9a-f]{6}", value):
            raise ValueError("target_hex must be #RRGGBB")
        return value

    @model_validator(mode="after")
    def capacity_matches_available_wells(self) -> "SourceInput":
        occupied = sorted(set(self.occupied_wells))
        if any(well < 0 or well > 11 for well in occupied):
            raise ValueError("occupied_wells must contain only indices 0 through 11")
        if self.max_wells > 12 - len(occupied):
            raise ValueError("max_wells exceeds the number of unoccupied wells")
        if set(self.source_used_ul) != {"red", "yellow", "blue"}:
            raise ValueError("source_used_ul must contain red, yellow, and blue")
        if any(value < 0 or value > 12000 for value in self.source_used_ul.values()):
            raise ValueError("source_used_ul values must be between 0 and 12000")
        self.occupied_wells = occupied
        return self


class ColorRecipe(BaseModel):
    red_ul: int = Field(ge=0, le=1000)
    yellow_ul: int = Field(ge=0, le=1000)
    blue_ul: int = Field(ge=0, le=1000)

    @computed_field
    @property
    def total_ul(self) -> int:
        return self.red_ul + self.yellow_ul + self.blue_ul

    @model_validator(mode="after")
    def exact_total(self) -> "ColorRecipe":
        if self.total_ul != 1000:
            raise ValueError("recipe volumes must total exactly 1000 uL")
        return self

    def as_color_dict(self) -> dict[str, int]:
        return {"red": self.red_ul, "yellow": self.yellow_ul, "blue": self.blue_ul}


class DesignDecision(BaseModel):
    recipe: ColorRecipe
    reasoning: str
    confidence: float = Field(ge=0.0, le=1.0)


class ExperimentObservation(BaseModel):
    well: int = Field(ge=0, le=11)
    recipe: ColorRecipe
    difference: float = Field(ge=0)
    design_reasoning: str
    confidence: float = Field(ge=0.0, le=1.0)


class InitToken(BaseModel):
    ready: bool = True


class MadeExperiment(BaseModel):
    well: int
    decision: DesignDecision
    source_allocations: dict[str, list[tuple[int, int]]] = Field(default_factory=dict)


class AnalysisDecision(BaseModel):
    continue_experimenting: bool
    stop_reason: StopReason | None = None
    latest: ExperimentObservation | None = None


class ColorMatchingResult(BaseModel):
    run_id: str
    status: ExecutionStatus
    is_real_result: bool
    target_hex: str
    threshold: float
    stop_reason: StopReason
    filled_wells: int
    best_difference: float | None = None
    best_well: int | None = None
    best_recipe: ColorRecipe | None = None
    observations: list[ExperimentObservation] = Field(default_factory=list)
    progress_log_path: str
    final_json_path: str
    provenance_path: str
    failure_messages: list[str] = Field(default_factory=list)


@dataclass
class WorkflowState:
    source_input: SourceInput
    run_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    started_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    run_dir: str = ""
    next_well: int = 0
    observations: list[ExperimentObservation] = field(default_factory=list)
    current_design: DesignDecision | None = None
    status: ExecutionStatus = "ok"
    stop_reason: StopReason | None = None
    failure_messages: list[str] = field(default_factory=list)
    routing_history: list[dict[str, Any]] = field(default_factory=list)
    step_records: list[dict[str, Any]] = field(default_factory=list)
    source_remaining: dict[str, list[list[int]]] = field(
        default_factory=lambda: {
            "blue": [[0, 6000], [3, 6000]],
            "yellow": [[1, 6000], [4, 6000]],
            "red": [[2, 6000], [5, 6000]],
        }
    )

    def __post_init__(self) -> None:
        occupied = self.source_input.occupied_wells
        self.next_well = 0 if not occupied else max(occupied) + 1
        for color, used in self.source_input.source_used_ul.items():
            remaining_used = used
            for source in self.source_remaining[color]:
                take = min(source[1], remaining_used)
                source[1] -= take
                remaining_used -= take
                if remaining_used == 0:
                    break
            if remaining_used:
                raise ValueError(f"source_used_ul exceeds available {color} volume")

    def allocate(self, color: str, volume_ul: int) -> list[tuple[int, int]]:
        remaining = volume_ul
        allocations: list[tuple[int, int]] = []
        for source in self.source_remaining[color]:
            well, available = source
            take = min(available, remaining)
            if take:
                allocations.append((well, take))
                source[1] -= take
                remaining -= take
            if remaining == 0:
                break
        if remaining:
            raise RuntimeError(f"insufficient {color} source volume for {volume_ul} uL")
        return allocations
