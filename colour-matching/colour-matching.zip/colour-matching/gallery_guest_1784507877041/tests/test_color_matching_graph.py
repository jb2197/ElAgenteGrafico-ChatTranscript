from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from color_matching_graph.execution import run_color_matching
from color_matching_graph.models import ColorRecipe, DesignDecision, ExperimentObservation, SourceInput


class FakeDesigner:
    def __init__(self, recipes: list[ColorRecipe]):
        self.recipes = iter(recipes)

    async def design(self, target_hex, observations, next_well):
        recipe = next(self.recipes)
        return DesignDecision(recipe=recipe, reasoning=f"test recipe for well {next_well}", confidence=1.0)


class FakeRobot:
    def __init__(self, diffs: list[float]):
        self.diffs = iter(diffs)
        self.calls = []

    async def connect(self): self.calls.append(("connect", {}))
    async def close(self): self.calls.append(("close", {}))
    async def initialize(self): self.calls.append(("initialize", {}))
    async def return_home(self): self.calls.append(("return_home", {}))

    async def make_recipe(self, well, recipe, source_wells):
        self.calls.append(("make_recipe", {"well": well, "recipe": recipe.model_dump(), "source_wells": source_wells}))

    async def color_diff(self, well, target_hex):
        value = next(self.diffs)
        self.calls.append(("color_diff", {"well": well, "hex": target_hex, "difference": value}))
        return value


@pytest.mark.parametrize("values", [(900, 100, 0), (0, 0, 1000)])
def test_recipe_accepts_exactly_1000_ul(values):
    red, yellow, blue = values
    assert ColorRecipe(red_ul=red, yellow_ul=yellow, blue_ul=blue).total_ul == 1000


def test_recipe_rejects_wrong_total():
    with pytest.raises(ValidationError):
        ColorRecipe(red_ul=500, yellow_ul=100, blue_ul=100)


@pytest.mark.asyncio
async def test_stops_below_threshold(tmp_path: Path):
    result = await run_color_matching(
        SourceInput(target_hex="#eb4034", max_wells=12, threshold=10),
        run_root=tmp_path,
        designer=FakeDesigner([ColorRecipe(red_ul=900, yellow_ul=100, blue_ul=0)]),
        robot=FakeRobot([7.5]),
        dry_run=True,
    )
    assert result.status == "ok"
    assert result.stop_reason == "threshold_reached"
    assert result.filled_wells == 1
    assert result.best_difference == 7.5
    assert result.is_real_result is False


@pytest.mark.asyncio
async def test_stops_after_all_wells(tmp_path: Path):
    recipes = [ColorRecipe(red_ul=1000, yellow_ul=0, blue_ul=0) for _ in range(12)]
    result = await run_color_matching(
        SourceInput(target_hex="#eb4034", max_wells=12, threshold=10),
        run_root=tmp_path,
        designer=FakeDesigner(recipes),
        robot=FakeRobot([20.0] * 12),
        dry_run=True,
    )
    assert result.status == "partial"
    assert result.stop_reason == "wells_exhausted"
    assert result.filled_wells == 12


@pytest.mark.asyncio
async def test_failure_is_recorded(tmp_path: Path):
    class BrokenRobot(FakeRobot):
        async def make_recipe(self, well, recipe, source_wells):
            raise RuntimeError("pump jam")

    result = await run_color_matching(
        SourceInput(),
        run_root=tmp_path,
        designer=FakeDesigner([ColorRecipe(red_ul=1000, yellow_ul=0, blue_ul=0)]),
        robot=BrokenRobot([20.0]),
        dry_run=True,
    )
    assert result.status == "failed"
    assert "pump jam" in "\n".join(result.failure_messages)
    assert (tmp_path / result.run_id / "provenance.json").exists()

@pytest.mark.asyncio
async def test_respects_previously_occupied_wells(tmp_path: Path):
    robot = FakeRobot([8.0])
    result = await run_color_matching(
        SourceInput(
            target_hex="#42f5f5",
            max_wells=11,
            occupied_wells=[0],
            source_used_ul={"red": 900, "yellow": 80, "blue": 20},
        ),
        run_root=tmp_path,
        designer=FakeDesigner([ColorRecipe(red_ul=0, yellow_ul=200, blue_ul=800)]),
        robot=robot,
        dry_run=True,
    )
    make_call = next(payload for name, payload in robot.calls if name == "make_recipe")
    assert make_call["well"] == 1
    assert result.best_well == 1


def test_designer_prompt_is_target_agnostic():
    from color_matching_graph.designer import SYSTEM_PROMPT
    assert "#eb4034" not in SYSTEM_PROMPT.lower()
    assert "supplied" in SYSTEM_PROMPT.lower()


@pytest.mark.asyncio
async def test_robot_returns_home_before_camera_measurement(tmp_path: Path):
    robot = FakeRobot([7.0])
    await run_color_matching(
        SourceInput(target_hex="#af877b"),
        run_root=tmp_path,
        designer=FakeDesigner([ColorRecipe(red_ul=600, yellow_ul=250, blue_ul=150)]),
        robot=robot,
        dry_run=True,
    )
    names = [name for name, _ in robot.calls]
    make_index = names.index("make_recipe")
    diff_index = names.index("color_diff")
    assert "return_home" in names[make_index + 1:diff_index]
