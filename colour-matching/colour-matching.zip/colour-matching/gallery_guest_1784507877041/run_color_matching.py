from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from color_matching_graph.execution import run_color_matching_sync
from color_matching_graph.models import SourceInput


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the adaptive color-matching execution graph.")
    parser.add_argument("--target", default="#eb4034")
    parser.add_argument("--threshold", type=float, default=10.0)
    parser.add_argument("--max-wells", type=int, default=12)
    parser.add_argument("--mcp-url", default="http://localhost:8001/mcp")
    parser.add_argument("--run-root", type=Path, default=Path("artifacts/color_matching_runs"))
    args = parser.parse_args()
    result = run_color_matching_sync(
        SourceInput(target_hex=args.target, threshold=args.threshold, max_wells=args.max_wells),
        run_root=args.run_root,
        mcp_url=args.mcp_url,
    )
    print(json.dumps(result.model_dump(mode="json"), indent=2))
    raise SystemExit(0 if result.status in {"ok", "partial"} else 1)


if __name__ == "__main__":
    main()
