from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from color_matching_graph.mcp_client import MCPColorRobot
from color_matching_graph.models import ColorRecipe, SourceInput
from color_matching_graph.recovery import RecoveryInput, run_recovery


async def main() -> None:
    result = await run_recovery(
        RecoveryInput(
            parent_run_id="f9952a15-0c68-4294-8a7a-e82c69164804",
            well=0,
            recipe=ColorRecipe(red_ul=900, yellow_ul=80, blue_ul=20),
            difference=6.083963773603829,
            design_reasoning=(
                "Red-dominant initial experiment with modest yellow to warm the hue "
                "and a small blue fraction to moderate saturation."
            ),
            confidence=0.58,
        ),
        source_input=SourceInput(target_hex="#eb4034", threshold=10, max_wells=12),
        run_root=Path("artifacts/color_matching_runs"),
        robot=MCPColorRobot("http://localhost:8001/mcp"),
    )
    print(json.dumps(result.model_dump(mode="json"), indent=2))


if __name__ == "__main__":
    asyncio.run(main())
