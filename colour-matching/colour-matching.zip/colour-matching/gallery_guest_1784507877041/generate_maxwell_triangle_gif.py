from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.colors import Normalize
from matplotlib.patches import Polygon, Rectangle


def barycentric_xy(red: float, yellow: float, blue: float) -> tuple[float, float]:
    total = red + yellow + blue
    weights = np.array([red, yellow, blue], dtype=float) / total
    vertices = np.array([[0.5, math.sqrt(3) / 2], [0.0, 0.0], [1.0, 0.0]])
    return tuple(weights @ vertices)


def ideal_ryb_preview(red: float, yellow: float, blue: float) -> tuple[float, float, float]:
    total = red + yellow + blue
    weights = np.array([red, yellow, blue], dtype=float) / total
    primaries = np.array([[1.0, 0.08, 0.05], [1.0, 0.9, 0.0], [0.08, 0.2, 1.0]])
    return tuple(np.clip(weights @ primaries, 0, 1))


def triangle_background(ax, resolution: int = 85) -> None:
    vertices = np.array([[0.5, math.sqrt(3) / 2], [0.0, 0.0], [1.0, 0.0]])
    for r_i in range(resolution + 1):
        for y_i in range(resolution + 1 - r_i):
            b_i = resolution - r_i - y_i
            weights = np.array([r_i, y_i, b_i], dtype=float) / resolution
            xy = weights @ vertices
            color = ideal_ryb_preview(*weights)
            ax.scatter(*xy, s=90, color=color, marker="h", linewidths=0, alpha=0.78, zorder=0)
    ax.add_patch(Polygon(vertices, closed=True, fill=False, edgecolor="#222222", linewidth=2.2, zorder=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_json", type=Path)
    parser.add_argument("output_gif", type=Path)
    args = parser.parse_args()

    data = json.loads(args.input_json.read_text(encoding="utf-8"))
    observations = data["observations"]
    target = data["target_hex"]
    diffs = np.array([obs["difference"] for obs in observations], dtype=float)
    xs, ys, previews = [], [], []
    for obs in observations:
        recipe = obs["recipe"]
        xs.append(barycentric_xy(recipe["red_ul"], recipe["yellow_ul"], recipe["blue_ul"])[0])
        ys.append(barycentric_xy(recipe["red_ul"], recipe["yellow_ul"], recipe["blue_ul"])[1])
        previews.append(ideal_ryb_preview(recipe["red_ul"], recipe["yellow_ul"], recipe["blue_ul"]))

    fig = plt.figure(figsize=(9.5, 8.2), facecolor="#f5f3ef")
    ax = fig.add_axes([0.06, 0.08, 0.68, 0.84])
    panel = fig.add_axes([0.77, 0.08, 0.21, 0.84])
    panel.axis("off")
    triangle_background(ax)
    ax.set_aspect("equal")
    ax.set_xlim(-0.07, 1.07)
    ax.set_ylim(-0.08, 0.96)
    ax.axis("off")
    ax.text(0.5, 0.91, "RED", ha="center", va="bottom", fontsize=14, weight="bold", color="#9e1717")
    ax.text(-0.02, -0.035, "YELLOW", ha="left", va="top", fontsize=14, weight="bold", color="#8c7600")
    ax.text(1.02, -0.035, "BLUE", ha="right", va="top", fontsize=14, weight="bold", color="#174c9e")

    norm = Normalize(vmin=float(diffs.min()), vmax=float(diffs.max()))
    cmap = plt.get_cmap("viridis_r")
    path_line, = ax.plot([], [], color="#202020", linewidth=1.8, alpha=0.65, zorder=4)
    scatter = ax.scatter([], [], s=[], c=[], cmap=cmap, norm=norm, edgecolors="white", linewidths=1.5, zorder=5)
    current_ring = ax.scatter([], [], s=300, facecolors="none", edgecolors="#ffffff", linewidths=3.0, zorder=7)
    best_star = ax.scatter([], [], s=360, marker="*", facecolors="#ffd43b", edgecolors="#111111", linewidths=1.2, zorder=8)

    panel.text(0.5, 0.97, "MAXWELL COLOUR\nTRIANGLE", ha="center", va="top", fontsize=16, weight="bold")
    panel.text(0.5, 0.86, "Target", ha="center", fontsize=11, weight="bold")
    panel.add_patch(Rectangle((0.18, 0.77), 0.64, 0.075, transform=panel.transAxes, facecolor=target, edgecolor="#222", linewidth=1.5))
    panel.text(0.5, 0.745, target.upper(), ha="center", fontsize=12, family="monospace")
    panel.text(0.06, 0.66, "Current experiment", fontsize=11, weight="bold")
    current_swatch = Rectangle((0.06, 0.57), 0.88, 0.065, transform=panel.transAxes, edgecolor="#222", linewidth=1.2)
    panel.add_patch(current_swatch)
    info = panel.text(0.06, 0.53, "", va="top", fontsize=10.5, linespacing=1.5, family="monospace")
    best_info = panel.text(0.06, 0.27, "", va="top", fontsize=10.5, linespacing=1.5, family="monospace")
    panel.text(0.06, 0.11, "Marker colour encodes ΔE\n(yellow = lower/better).", fontsize=9.5, color="#444")
    title = fig.suptitle("", y=0.985, fontsize=15, weight="bold")

    def update(frame: int):
        n = frame + 1
        shown_x = xs[:n]
        shown_y = ys[:n]
        path_line.set_data(shown_x, shown_y)
        scatter.set_offsets(np.column_stack([shown_x, shown_y]))
        scatter.set_sizes([105] * n)
        scatter.set_array(diffs[:n])
        current_ring.set_offsets([[xs[frame], ys[frame]]])
        best_index = int(np.argmin(diffs[:n]))
        best_star.set_offsets([[xs[best_index], ys[best_index]]])

        obs = observations[frame]
        recipe = obs["recipe"]
        current_swatch.set_facecolor(previews[frame])
        info.set_text(
            f"Well {obs['well']}\n"
            f"R {recipe['red_ul']:4d} µL\n"
            f"Y {recipe['yellow_ul']:4d} µL\n"
            f"B {recipe['blue_ul']:4d} µL\n"
            f"ΔE {obs['difference']:.3f}"
        )
        best_obs = observations[best_index]
        best_recipe = best_obs["recipe"]
        best_info.set_text(
            "Best so far\n"
            f"Well {best_obs['well']}\n"
            f"R/Y/B {best_recipe['red_ul']}/"
            f"{best_recipe['yellow_ul']}/"
            f"{best_recipe['blue_ul']} µL\n"
            f"ΔE {best_obs['difference']:.3f}"
        )
        title.set_text(f"Adaptive colour-matching trajectory — experiment {n}/{len(observations)}")
        return path_line, scatter, current_ring, best_star, current_swatch, info, best_info, title

    animation = FuncAnimation(fig, update, frames=len(observations), interval=950, blit=False, repeat=True)
    args.output_gif.parent.mkdir(parents=True, exist_ok=True)
    animation.save(args.output_gif, writer=PillowWriter(fps=1), dpi=120)
    plt.close(fig)

    best_index = int(np.argmin(diffs))
    print(json.dumps({
        "frames": len(observations),
        "best_well": observations[best_index]["well"],
        "best_difference": float(diffs[best_index]),
        "output": str(args.output_gif),
    }, indent=2))


if __name__ == "__main__":
    main()
